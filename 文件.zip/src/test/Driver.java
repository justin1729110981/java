package test;

import java.util.ArrayList;
import java.util.Scanner;

public class Driver {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int choiceIn =0;
		int choiceOut = 0;
		
		Dao dao = new Dao();
		ArrayList<Student> Stulist = null;
		ArrayList<Course> Coulist = null;
		ArrayList<Student> StuResult = null;
		ArrayList<Result> coResult = null;
		
		while(choiceIn != 4){
			choiceIn = MenuInput();
			switch(choiceIn){
			case 1: 
				Stulist = dao.inputStudent();
				Coulist = dao.inputCourse();
				while((choiceOut = MenuOutput() ) != 4){
					switch(choiceOut){
					case 1: 
						StuResult = dao.pocessByStudent(Stulist, Coulist);
						coResult = dao.listCoursepocessByCourse(Coulist);
						dao.print(StuResult, coResult);
						System.out.println("�����ɹ���");
						break;
					case 2: 
						StuResult = dao.pocessByStudent(Stulist, Coulist);
						coResult = dao.listCoursepocessByCourse(Coulist);
						dao.writeTxT(StuResult, coResult);
						System.out.println("�����ɹ���");
						break;
					case 3: 
						StuResult = dao.pocessByStudent(Stulist, Coulist);
						coResult = dao.listCoursepocessByCourse(Coulist);
						dao.writeExcel(StuResult, coResult);
						System.out.println("�����ɹ���");
						break;

					default: System.out.println("Menu error input!");
					}
				}
				break;
			case 2: 
				Stulist = dao.importStudentFromTxT();
				Coulist = dao.importCourseFromTxT();
				while((choiceOut = MenuOutput() ) != 4){
					switch(choiceOut){
					case 1: 
						StuResult = dao.pocessByStudent(Stulist, Coulist);
						coResult = dao.listCoursepocessByCourse(Coulist);
						dao.print(StuResult, coResult);
						System.out.println("�����ɹ���");
						break;
					case 2: 
						StuResult = dao.pocessByStudent(Stulist, Coulist);
						coResult = dao.listCoursepocessByCourse(Coulist);
						dao.writeTxT(StuResult, coResult);
						System.out.println("�����ɹ���");
						break;
					case 3: 
						StuResult = dao.pocessByStudent(Stulist, Coulist);
						coResult = dao.listCoursepocessByCourse(Coulist);
						dao.writeExcel(StuResult, coResult);
						System.out.println("�����ɹ���");
						break;

					default: System.out.println("Menu error input!");
					}
				}
				break;
			case 3:
				Stulist = dao.importStudentFromExcel();
				Coulist = dao.importCourseFromExcel();
				while((choiceOut = MenuOutput() ) != 4){
					switch(choiceOut){
					case 1: 
						StuResult = dao.pocessByStudent(Stulist, Coulist);
						coResult = dao.listCoursepocessByCourse(Coulist);
						dao.print(StuResult, coResult);
						System.out.println("�����ɹ���");
						break;
					case 2: 
						StuResult = dao.pocessByStudent(Stulist, Coulist);
						coResult = dao.listCoursepocessByCourse(Coulist);
						dao.writeTxT(StuResult, coResult);
						System.out.println("�����ɹ���");
						break;
					case 3: 
						StuResult = dao.pocessByStudent(Stulist, Coulist);
						coResult = dao.listCoursepocessByCourse(Coulist);
						dao.writeExcel(StuResult, coResult);
						System.out.println("�����ɹ���");
						break;

					default: System.out.println("Menu error input!");
					}
				}
				break;
			case 4:
				choiceIn = 4;
				break;

			default: System.out.println("Menu error input!");
			}
			
		}
		
		System.out.println("��ӭ�ٴ�ʹ��ϵͳ!");
		
		
	}
	
	public static int MenuInput(){
		int choice = 0;
		
		System.out.println("========Menu========");
		System.out.println("1.�ֶ��������ݡ�");
		System.out.println("2.TxT�ļ��������ݡ�");
		System.out.println("3.Excel�ļ��������ݡ�");
		System.out.println("4.Exit��");
		System.out.println("========�ָ���========");
		System.out.print("������˵�����ѡ��(1-3):");
		Scanner scan = new Scanner(System.in);
		choice = scan.nextInt();
		
		return choice;
	}
	
	public static int MenuOutput(){
		int choice = 0;
		
		System.out.println("========Menu========");
		System.out.println("1.ֱ��������ݡ�");
		System.out.println("2.����ΪTxT�ļ����ݡ�");
		System.out.println("3.����ΪExcel�ļ����ݡ�");
		System.out.println("4.Exit��");
		System.out.println("========�ָ���========");
		System.out.print("������˵�����ѡ��(1-3):");
		Scanner scan = new Scanner(System.in);
		choice = scan.nextInt();
		
		return choice;
	}

}
