package test;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Scanner;

import jxl.Cell;
import jxl.Sheet;
import jxl.Workbook;
import jxl.write.Label;
import jxl.write.WritableSheet;
import jxl.write.WritableWorkbook;

public class Dao {
	
	public ArrayList<Student> inputStudent(){
		ArrayList<Student> Stulist = new ArrayList<Student>();
		
		System.out.println("�����ʽΪ:ѧ�ţ��������Ա�\\n(������endʱ����):");
		@SuppressWarnings("resource")
		Scanner scan = new Scanner(System.in);
		String stu = scan.nextLine();
		while(!stu.equals("end")){
			String array[] = stu.split(",|��");
			Student student = new Student(array[0], array[1], array[2]);
			Stulist.add(student);
			stu = scan.nextLine();
		}
		System.out.println("����ɹ���");
		return Stulist;
	}
	
	public ArrayList<Student> importStudentFromTxT(){
		ArrayList<Student> listStudent = new ArrayList<Student>();
		
		try{
			File file = new File("C://Users//Nava9//Desktop//�ļ�//src//Student.txt");
			FileReader fr = new FileReader(file);
			BufferedReader bf = new BufferedReader(fr);
			String aline = "";
			while((aline = bf.readLine()) != null){
				String array[] = aline.split(",|��");
				Student stu = new Student(array[0], array[1], array[2]);
				listStudent.add(stu);
			}
			
		}catch (Exception e) {
			e.printStackTrace();
		}
		System.out.println("Student��TxT����ɹ���");
		return listStudent;
	}
	
	public ArrayList<Student> importStudentFromExcel(){
		ArrayList<Student> listStudent = new ArrayList<Student>();
		
		try{
			File file = new File("C://Users//Nava9//Desktop//�ļ�//src//Student.txt");
			
			Workbook workbook = Workbook.getWorkbook(file);
			Sheet sheet = workbook.getSheet(0);
			
			int columns = sheet.getColumns();
			int rows = sheet.getRows();
			
			for(int i = 1; i < rows; i++) {
				Cell cell0 = sheet.getCell(0, i);
				String id = cell0.getContents();
				Cell cell1 = sheet.getCell(1, i);
				String name = cell1.getContents();
				Cell cell2 = sheet.getCell(2, i);
				String gender = cell2.getContents();
				Student stu = new Student(id, name, gender);
				listStudent.add(stu);
			}
			workbook.close();
			
		}catch (Exception e) {
			e.printStackTrace();
		}
		System.out.println("Student��Excel����ɹ���");
		return listStudent;
	}
	
	public ArrayList<Course> inputCourse(){
		ArrayList<Course> courlist = new ArrayList<Course>();
		
		System.out.println("�����ʽΪ:ѧ�ţ��γ����ƣ��ɼ�\\n(������endʱ����):");
		@SuppressWarnings("resource")
		Scanner scan = new Scanner(System.in);
		String cour = scan.nextLine();
		while(!cour.equals("end")){
			String array[] = cour.split(",|��");
			Course course = new Course(array[0], array[1], Float.parseFloat(array[2]));
			courlist.add(course);
			cour = scan.nextLine();
		}
		System.out.println("����ɹ���");
		return courlist;
	}
	
	public ArrayList<Course> importCourseFromTxT(){
		ArrayList<Course> listCourse = new ArrayList<Course>();
		
		try{
			File file = new File("C://Users//Nava9//Desktop//�ļ�//src//Course.txt");
			FileReader fr = new FileReader(file);
			BufferedReader bf = new BufferedReader(fr);
			String aline = "";
			while((aline = bf.readLine()) != null){
				String array[] = aline.split(",|��");
				Course course = new Course(array[0], array[1], Float.parseFloat(array[2]));
				listCourse.add(course);
			}
			
		}catch (Exception e) {
			e.printStackTrace();
		}
		System.out.println("Course��TxT����ɹ���");
		return listCourse;
	}
	
	public ArrayList<Course> importCourseFromExcel(){
		ArrayList<Course> listCourse = new ArrayList<Course>();
		
		try{
			File file = new File("C://Users//Nava9//Desktop//�ļ�//src//course.xls");
			
			Workbook workbook = Workbook.getWorkbook(file);
			Sheet sheet = workbook.getSheet(0);
			
			int columns = sheet.getColumns();
			int rows = sheet.getRows();
			
			for(int i = 1; i < rows; i++) {
				Cell cell0 = sheet.getCell(0, i);
				String id = cell0.getContents();
				Cell cell1 = sheet.getCell(1, i);
				String courseName = cell1.getContents();
				Cell cell2 = sheet.getCell(2, i);
				String grade = cell2.getContents();
				Course cou = new Course(id, courseName, Float.parseFloat(grade));
				listCourse.add(cou);
			}
			workbook.close();
			
		}catch (Exception e) {
			e.printStackTrace();
		}
		System.out.println("Course��Excel����ɹ���");
		return listCourse;
		
	}
	
	public ArrayList<Student> pocessByStudent(ArrayList<Student> listStudent,ArrayList<Course> listCourse){
		ArrayList<Student> stResult = new ArrayList<Student>();
		for (Student student : listStudent) {
			int count = 0;
			float sum = 0;
			String id = student.getId();
			for (Course course : listCourse) {
				if(id.equals(course.getId())) {
					count++;
					sum += course.getGrade();
				}
			}
			float avg = sum/count;
			student.setAvg(avg);
			stResult.add(student);
		}
		return stResult;
	}
	
	public ArrayList<Result> listCoursepocessByCourse(ArrayList<Course> listCourse){
		ArrayList<Result> coResult = new ArrayList<Result>();
		for (Course course : listCourse) {
			int index = find(coResult, course.getCourseName());
			if(index == -1) {
				Result result = new Result(course.getCourseName(), 0);
				coResult.add(result);
			}
		}
		
		for(int i = 0; i < coResult.size(); i++) {
			Result result  = coResult.get(i);
			int count = 0;
			float sum = 0;
			String courseName = result.getCourseName();
			for (Course course : listCourse) {
				if(courseName.equals(course.getCourseName())) {
					sum += course.getGrade();
					count++;
				}
			}
			float avg = sum/count;
			result.setAvg(avg);
			coResult.set(i, result);
		}
		
		return coResult;
	}
	
	private int find(ArrayList<Result> result,String courseName) {
		int index = -1;
		for(int i = 0; i < result.size() ; i++) {
			if(result.get(i).getCourseName().equals(courseName)) {
				index = i;
				break;
			}
		}
		return index;
		
	}
	
	
	
	public void print(ArrayList<Student> listStudent,ArrayList<Result> listResult){
		System.out.println("================Result=================");
		System.out.println("��ѧ��ͳ�ƣ�");
		System.out.println("ѧ��\t����\t�Ա�\tƽ����");
		for (Student student : listStudent) {
			System.out.println(student.toString());
		}
		System.out.println("���γ�ͳ�ƣ�");
		System.out.println("�γ�\tƽ����");
		for (Result result : listResult) {
			System.out.println(result.toString());
		}
		System.out.println("=================end===================");
		
	}
	
	public void writeTxT(ArrayList<Student> listStudent,ArrayList<Result> listResult){
		File file = new File("C://Users//Nava9//Desktop//�ļ�//src//resutl.txt");
		try{
			FileWriter fw = new FileWriter(file);
			PrintWriter pw = new PrintWriter(fw);
			
			pw.println("��ѧ��ͳ�ƣ�");
			pw.println("ѧ��\t����\t�Ա�\tƽ����");
			for (Student student : listStudent) {
				pw.println(student.toString());
			}
			pw.println();
			pw.println("���γ�ͳ�ƣ�");
			pw.println("�γ�\tƽ����");
			for (Result result : listResult) {
				pw.println(result.toString());
			}
			
			pw.close();
			fw.close();
			
		}catch (Exception e) {
			e.printStackTrace();
		}
		System.out.println("����ΪTxT�ļ��ɹ���");
	}
	
	public void writeExcel(ArrayList<Student> listStudent,ArrayList<Result> listResult){
		int snum = listStudent.size();
		int cnum = listResult.size();
		try{
			File file = new File("C://Users//Nava9//Desktop//�ļ�//src//ResultExcel.xls");
			WritableWorkbook workbook = Workbook.createWorkbook(file);
			
			WritableSheet sheet1 = workbook.createSheet("ѧ��ͳ��", 0);
			Label labelS1 = new Label(0, 0, "ѧ��");
			sheet1.addCell(labelS1);
			Label labelS2 = new Label(1, 0, "����");
			sheet1.addCell(labelS2);
			Label labelS3 = new Label(2, 0, "�Ա�");
			sheet1.addCell(labelS3);
			Label labelS4 = new Label(3, 0, "ƽ����");
			sheet1.addCell(labelS4);
			for (int i = 0; i < snum; i++) {
				String id = listStudent.get(i).getId();
				Label label10 = new Label(0, i+1, id);
				sheet1.addCell(label10);
				String name = listStudent.get(i).getName();
				Label label11 = new Label(1, i+1, name);
				sheet1.addCell(label11);
				String gender = listStudent.get(i).getGender();
				Label label12 = new Label(2, i+1, gender);
				sheet1.addCell(label12);
				float avg = listStudent.get(i).getAvg();
				Label label13 = new Label(3, i+1, String.valueOf(avg));
				sheet1.addCell(label13);
			}
			
			WritableSheet sheet2 = workbook.createSheet("�γ�ͳ��", 1);
			Label labelC1 = new Label(0, 0, "�γ�");
			sheet2.addCell(labelC1);
			Label labelC2 = new Label(1, 0, "ƽ����");
			sheet2.addCell(labelC2);
			for (int i = 0; i < cnum; i++) {
				String courseName = listResult.get(i).getCourseName();
				Label label10 = new Label(0, i+1, courseName);
				sheet2.addCell(label10);
				float avg = listResult.get(i).getAvg();
				Label label11 = new Label(1, i+1, String.valueOf(avg));
				sheet2.addCell(label11);
				
			}
			
			workbook.write();
			workbook.close();
			
		}catch(Exception e){
			e.printStackTrace();
		}
		System.out.println("����ΪExcel�ļ��ɹ���");
	}
	

}
