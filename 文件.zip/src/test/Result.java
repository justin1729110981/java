package test;

public class Result {
	private String courseName;
	private float avg;
	
	public Result() {
		super();
	}
	
	public Result(String courseName, float avg) {
		super();
		this.courseName = courseName;
		this.avg = avg;
	}

	public String getCourseName() {
		return courseName;
	}

	public void setCourseName(String courseName) {
		this.courseName = courseName;
	}

	public float getAvg() {
		return avg;
	}

	public void setAvg(float avg) {
		this.avg = avg;
	}

	@Override
	public String toString() {
		return courseName + "\t" + avg;
	}
	

}
