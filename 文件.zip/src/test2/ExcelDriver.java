package test2;

import java.io.File;

import jxl.Cell;
import jxl.Sheet;
import jxl.Workbook;
import jxl.write.Label;
import jxl.write.WritableSheet;
import jxl.write.WritableWorkbook;

public class ExcelDriver {
	/*
	public static void main(String[] args) {
		try{
			File file = new File("C://Users//18308//Desktop//Week-12//Week-12//bin//Files//student.xls");
			Workbook workbook = Workbook.getWorkbook(file);
			Sheet sheet = workbook.getSheet(0);
			
			int columns = sheet.getColumns();
			int rows = sheet.getRows();
			
			for(int i = 0; i < rows; i++) {
				for(int j = 0; j < columns; j++) {
					Cell cell = sheet.getCell(j, i);
					String s = cell.getContents();
					System.out.print(s + "\t");
					
				}
				System.out.println();
			}
			workbook.close();
			
		}catch(Exception e){
			e.printStackTrace();
		}
	}
	*/
	
	public static void main(String[] args) {
		try{
			File file = new File("C://Users//Nava9//Desktop//�ļ�//src//test.xls");
			WritableWorkbook workbook = Workbook.createWorkbook(file);
			WritableSheet sheet = workbook.createSheet("ѧ����Ϣ", 0);
			
			Label label0 = new Label(0, 0, "ѧ��");
			sheet.addCell(label0);
			Label label1 = new Label(1, 0, "����");
			sheet.addCell(label1);
			
			workbook.write();
			workbook.close();
			
		}catch(Exception e){
			e.printStackTrace();
		}
		
	}

}
